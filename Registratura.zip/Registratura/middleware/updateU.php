<?php
require_once('../controllers/User.php');
$db = new User();
$id_users = $_POST['id_users'];
$role = $_POST['role'];

$response = $db->updateU(json_encode([
    'id_users'=>$id_users,
    'role'=>$role,
]));

header('Location: ../index2.php?message='.json_decode($response)->message);
