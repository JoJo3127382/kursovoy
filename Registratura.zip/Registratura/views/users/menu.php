<div>
    <a class="knopka" href="../../index2.php">Главная</a>
</div>
<div class="container d-flex justify-content-between align-items-center p-2 mb-2 border_width">
    <div>Сотрудники</div>
    <div>
        <a class="knopka" href="create.php">Добавить сотрудника</a>
        <a class="knopka" href="update.php">Изменить данные сотрудника</a>
        <a class="knopka" href="delete.php">Удалить сотрудника</a>
    </div>
</div>