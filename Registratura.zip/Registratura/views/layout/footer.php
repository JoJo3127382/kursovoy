<!doctype html>
<html lang="ru">
<body>
<div class="container d-flex" style="background-color: #60ee9f">
    <label>Телефон:88005553535</label>
</div>
</body>
</html>